# Flex Globals

This repository contains the ActionScript sources for all of the Flex globals, including the base component set.