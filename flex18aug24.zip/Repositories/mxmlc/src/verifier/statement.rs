use crate::ns::*;

pub(crate) struct StatementSubverifier;

impl StatementSubverifier {
    pub fn verify_statements(verifier: &mut Subverifier, list: &[Rc<Directive>]) {
        todo_here();
    }
}