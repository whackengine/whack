# Unused warning

* [ ] Traverse all unused entities from `Unused(host).all()` and report a warning if unused warning is on.