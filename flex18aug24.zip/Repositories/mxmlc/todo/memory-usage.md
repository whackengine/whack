# Memory usage

## Node mapping

Clear the node-to-entity mapping after the external libraries (e.g. the Flex core) are fully compiled. This will save memory space.