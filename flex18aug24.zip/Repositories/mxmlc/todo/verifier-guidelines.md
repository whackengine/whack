# Verifier guidelines

## Preventing duplicate diagnostics

To prevent duplicate diagnostics, always report them only after the verification of a construct is fully done, after any deferred parts. Do so for each phase of a directive as well.