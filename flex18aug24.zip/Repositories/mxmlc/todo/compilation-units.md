# Compilation units

* [ ] Set the compiler options directly after creating a compilation unit (before any parsing and verification).