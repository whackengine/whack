# Function common

* [ ] Set scope carefully.
  * [x] Function expressions