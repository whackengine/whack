# Variable bindings

* [ ] Cache the topmost initializer for a variable binding and erase it after non deferred verification (`verifier.cached_var_init`).