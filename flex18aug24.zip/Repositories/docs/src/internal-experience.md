# Internal experience

The Flex implementation is split into two main modules: MXMLC and ActionCore.