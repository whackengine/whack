# Skinning

Skinning the user interface controls can be done both through a CSS3 subset and ActionScript 3.