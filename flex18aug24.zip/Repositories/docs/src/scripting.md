# Scripting

Flex allows customising logic and user interface layout and skins in three computer languages: ActionScript 3, MXML, and a CSS3 subset.