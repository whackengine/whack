# ActionCore

[ActionCore](https://github.com/hydroperflex/actioncore) is a JavaScript module for W3C and Node, which defines a large set of classes and functions that may be imported and called, comprising the ActionScript 3 environment.