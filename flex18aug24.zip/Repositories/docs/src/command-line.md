# Command line

The Flex command line interface allows you to create, compile and publish your MXML applications, your libraries and your own command line interfaces.