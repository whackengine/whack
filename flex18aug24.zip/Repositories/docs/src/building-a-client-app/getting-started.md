# Getting started

Here is an example entry point that is a MXML component:

```mxml
<!-- src/com/example/ExampleApplication.mxml -->
<?xml version="1.0"?>
<fx:Application xmlns:fx="http://ns.hydroper.com/flex/2024">
    <fx:Label text="Hello, world!"/>
</fx:Application>
```