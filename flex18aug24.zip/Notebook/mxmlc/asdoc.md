# ASDoc

## Object

Manually document public::constructor, prototype::hasOwnProperty(), prototype::toLocaleString(), prototype::toString() and prototype::valueOf(), as these do not appear as fixtures.

## Other

There are few other language classes that contain similiar prototype methods that need to be documented manually.
