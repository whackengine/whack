# JavaScript insertion

Process the `fx.externals.js` functions in a special way.
