# Configuration

## Global objects configuration

- [ ] `package { public namespace AS3 = "http://hydroper.com/AS3/2024/builtin"; }`
- [ ] `package fx.utils {}`
- [ ] `package fx.utils { public namespace fx_proxy = "http://hydroper.com/2024/actionscript/flex/proxy"; }`
